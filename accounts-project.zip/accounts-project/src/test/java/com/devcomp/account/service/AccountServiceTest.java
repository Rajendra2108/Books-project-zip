package com.devcomp.account.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.junit.Assert.fail;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
import com.devcomp.account.dao.AccountDao;
import com.devcomp.account.model.Account;

/**
 * Helps in get, create and delete accounts. 
 */
@RunWith(SpringRunner.class)
public class AccountServiceTest {

  private AccountDao accountDao;
  private AccountService accountService;
  
  @Before
  public void setUp() throws Exception {
    accountDao = new AccountDao();
    accountDao.prepareData();
    accountService = new AccountService(accountDao);
  }

  @Test
  public void testGetAccounts() {
    List<Account> accounts = accountService.getAccounts();
    assertThat(accounts, hasSize(3));
  }
  
  @Test
  public void testCreateAccount() {
    Account account = new Account(4, "Tim", "Clarke", "1235");
    accountService.createAccount(account);
    List<Account> accounts = accountService.getAccounts();
    assertThat(accounts, hasSize(4));
  }

  @Test
  public void testDeleteAccount() {
    accountService.deleteAccount(4);
    List<Account> accounts = accountService.getAccounts();
    assertThat(accounts, hasSize(3));
  }

}
