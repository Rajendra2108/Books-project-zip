package com.devcomp.account.controller;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import com.devcomp.account.model.Account;
import com.devcomp.account.model.AccountRequest;
import com.devcomp.account.model.AccountResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Integration tests
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class AccountControllerTest {
  
  @Autowired
  private MockMvc mockMvc;

  @Test
  public void shouldReturnAccounts() throws Exception {
    this.mockMvc.perform(get("/rest/account/json"))
        .andDo(print())
        .andExpect(status().isOk())
        .andExpect(content().json(asAccounts()));
   }
  
  @Test
  public void shouldCreateAccount() throws Exception {
    AccountResponse response = new AccountResponse();
    response.setMessage("Account Created");
    AccountRequest request = new AccountRequest(6, "Jimmy", "Tester", "1237");
    final ObjectMapper mapper = new ObjectMapper();

    this.mockMvc.perform(post("/rest/account/json")
        .content(mapper.writeValueAsString(request))
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isOk())
        .andExpect(content().json(new ObjectMapper().writeValueAsString(response)));
   }
  
  @Test
  public void shouldDeleteAccounts() throws Exception {
    AccountResponse response = new AccountResponse();
    response.setMessage("Account Deleted");
    this.mockMvc.perform(delete("/rest/account/json/2"))
        .andDo(print())
        .andExpect(status().isOk())
        .andExpect(content().json(new ObjectMapper().writeValueAsString(response)));
   }
  
  private String asAccounts() {
    List<Account>accounts  = new ArrayList<Account>(Arrays.asList(
        new Account(1, "John", "Doe", "1234"),
        new Account(3, "Jim", "Row", "1236"),
        new Account(6, "Jimmy", "Tester", "1237")        
        ));
    try {
      return new ObjectMapper().writeValueAsString(accounts);
    } catch (JsonProcessingException e) {
      throw new RuntimeException("Unable to get accounts file.", e);
    }
  }
  
}
