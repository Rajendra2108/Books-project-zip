package com.devcomp.account.model;

import lombok.Data;

@Data
public class AccountResponse {

  private String message;
}
