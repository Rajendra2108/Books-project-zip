package com.devcomp.account.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.annotation.PostConstruct;
import org.springframework.stereotype.Service;
import com.devcomp.account.model.Account;

/** 
 * Holds hard coded account data to simulate data source. 
 */
@Service
public class AccountDao {
  
private List<Account> accountData;
  
  public AccountDao() {
    accountData = new ArrayList<>();
  }
  
  @PostConstruct
  public void prepareData() {
    accountData  = new ArrayList<Account>(Arrays.asList(
        new Account(1, "John", "Doe", "1234"),
        new Account(2, "Jane", "Line", "1235"),
        new Account(3, "Jim", "Row", "1236")
        ));
  }
  
  public List<Account> getAccounts() {
    return accountData;
  }
  
  public boolean addAccount(Account account) {
    if (null != account && null != String.valueOf(account.getId()) && null != account.getAccountNumber()) {
      return accountData.add(account);
    }
    else {
      return false;
    }
  }
  
  public boolean deleteAccount(int accountId) {
    return accountData.removeIf(a -> a.getId() == accountId);
  }
}
