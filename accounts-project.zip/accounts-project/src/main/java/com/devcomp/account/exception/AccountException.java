package com.devcomp.account.exception;

public class AccountException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public AccountException(final String message) {
    super(message);
  }
  
  public AccountException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
