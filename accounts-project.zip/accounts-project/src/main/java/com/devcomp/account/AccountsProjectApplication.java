package com.devcomp.account;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Exercise to get, create and delete accounts.
 *
 */
@SpringBootApplication
public class AccountsProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountsProjectApplication.class, args);
	}
}
