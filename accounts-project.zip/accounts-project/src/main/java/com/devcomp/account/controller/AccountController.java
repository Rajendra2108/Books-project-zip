package com.devcomp.account.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.devcomp.account.model.Account;
import com.devcomp.account.model.AccountResponse;
import com.devcomp.account.service.AccountService;
import io.swagger.annotations.ApiParam;

/**
 * Handles get, create and delete account.
 */

@RestController
@RequestMapping(produces = {MediaType.APPLICATION_JSON_VALUE})
public class AccountController {

private final AccountService accountService;
  
  @Autowired
  public AccountController(AccountService accountService) {
    this.accountService = accountService;
  }

  @RequestMapping(path = "/rest/account/json", method = RequestMethod.GET)
  public ResponseEntity<List<Account>> getAccount() {
    
    return !CollectionUtils.isEmpty(accountService.getAccounts()) 
        ? new ResponseEntity<>(accountService.getAccounts(), HttpStatus.OK) 
            : new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
  }
  
  @RequestMapping(path = "/rest/account/json", method = RequestMethod.POST)
  public ResponseEntity<AccountResponse> createAccount(
      final @ApiParam(required = true, value = "Account to create")
      @RequestBody Account accountRequest) {
    
    AccountResponse response = new AccountResponse();
    if(accountService.createAccount(accountRequest)) {
      response.setMessage("Account Created");      
    }
    else {
      response.setMessage("Failed to create account");       
    }
    return new ResponseEntity<>(response, HttpStatus.OK);
  }
  
  @RequestMapping(path = "/rest/account/json/{accountId}", method = RequestMethod.DELETE)
  public ResponseEntity<AccountResponse> deleteAccount( 
    final @ApiParam(required = true, value="account Id") 
    @PathVariable("accountId") int accountId) {
    
    AccountResponse response = new AccountResponse();
    if(accountService.deleteAccount(accountId)) {
      response.setMessage("Account Deleted");      
    }
    else {
      response.setMessage("Record not found");       
    }
    return new ResponseEntity<>(response, HttpStatus.OK);
  }
}
