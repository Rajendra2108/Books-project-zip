package com.devcomp.account.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.devcomp.account.dao.AccountDao;
import com.devcomp.account.exception.AccountException;
import com.devcomp.account.model.Account;

/**
 * Manages account creation, deletion and retrieval
 */
@Service
public class AccountService {
  
  private AccountDao accountDao;
  
  @Autowired
  public AccountService(final AccountDao accountDao) {
    this.accountDao = accountDao;
  }
  
  public List<Account> getAccounts() {
    return accountDao.getAccounts();
  }
  
  public boolean createAccount(Account account) {
    if (null != account) {
      return accountDao.addAccount(account);      
    } 
    else {
      throw new AccountException("Invalid account data");
    }
  }
  
  public boolean deleteAccount(final int accountId) {
    if (null != String.valueOf(accountId)) {
      return accountDao.deleteAccount(accountId);      
    } 
    else {
      throw new AccountException("Invalid account Id provided to delete.");
    }
  }
}
